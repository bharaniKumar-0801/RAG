import { createAsyncThunk } from "@reduxjs/toolkit";
import { axiosAdminInstance } from "./axiosInstance";

interface AdminLoginPayload {
	email: string;
	password: string;
}

export const orgAdminLoginApi = createAsyncThunk("orgAdmin/login", async (credentials: AdminLoginPayload, { rejectWithValue }) => {
	try {
		const response = await axiosAdminInstance.post("/organization-admin/login", credentials);
		return response.data;
	} catch (error) {
		return rejectWithValue(error);
	}
});

interface CreateCategoryPayload {
	name: string;
}

export const orgCreateCategoryApi = createAsyncThunk("org/createCategory", async (category: CreateCategoryPayload, { rejectWithValue }) => {
	try {
		const response = await axiosAdminInstance.post("organization-admin/category", category);
		return response.data;
	} catch (error) {
		return rejectWithValue(error);
	}
});

export const orgUpdateCategoryApi = createAsyncThunk("org/updateCategory", async (category, { rejectWithValue }) => {
	try {
		const response = await axiosAdminInstance.put(`/organization-admin/categories/${category}`, category);
		return response.data;
	} catch (error) {
		return rejectWithValue(error);
	}
});

export const orgDeleteCategoryApi = createAsyncThunk("org/deleteCategory", async (categoryId: string, { rejectWithValue }) => {
	try {
		const response = await axiosAdminInstance.delete(`organization-admin/category/${categoryId}`);
		return response.data;
	} catch (error) {
		return rejectWithValue(error);
	}
});

export const orgGetCategoriesApi = createAsyncThunk("org/getCategories", async (_, { rejectWithValue }) => {
	try {
		const response = await axiosAdminInstance.get("/organization-admin/category");
		return response.data;
	} catch (error) {
		return rejectWithValue(error);
	}
});

export const orgCreateUserApi = createAsyncThunk("org/createUser", async (user: any, { rejectWithValue }) => {
	try {
		const response = await axiosAdminInstance.post("/organization-user", user);
		return response.data;
	} catch (error) {
		return rejectWithValue(error);
	}
});

export const orgUpdateUserApi = createAsyncThunk("org/updateUser", async (user: any, { rejectWithValue }) => {
	try {
		const response = await axiosAdminInstance.put(`/organization-admin/users/${user.id}`, user);
		return response.data;
	} catch (error) {
		return rejectWithValue(error);
	}
});

export const orgDeleteUserApi = createAsyncThunk("org/deleteUser", async (userId: string, { rejectWithValue }) => {
	try {
		const response = await axiosAdminInstance.delete(`/organization-user/${userId}`);
		return response.data;
	} catch (error) {
		return rejectWithValue(error);
	}
});

export const orgGetUsersApi = createAsyncThunk("org/getUsers", async (_, { rejectWithValue }) => {
	try {
		const response = await axiosAdminInstance.get("/organization-user");
		return response.data;
	} catch (error) {
		return rejectWithValue(error);
	}
});

interface IngestDocumentPayload {
	values: {
		category_id: string;
		file: File;
		tags: string[];
	};
	onProgress: (progress: number) => void;
}

export const orgIngestDocumentApi = createAsyncThunk("org/ingestDocument", async (document: IngestDocumentPayload, { rejectWithValue }) => {
	try {
		const formData = new FormData();
		formData.append("category_id", document.values.category_id);
		formData.append("file", document.values.file);
		formData.append("tags", JSON.stringify(document.values.tags));

		const response = await axiosAdminInstance.post("/organization-file/upload", formData, {
			headers: {
				"Content-Type": "multipart/form-data",
			},
			onUploadProgress: (progressEvent) => {
				const progress = Math.round((progressEvent.loaded * 100) / (progressEvent.total || 1));
				console.log(progress);
				document.onProgress(progress);
			},
		});
		return response.data;
	} catch (error) {
		return rejectWithValue(error);
	}
});

export const orgGetFilesApi = createAsyncThunk("org/getFiles", async (_, { rejectWithValue }) => {
	try {
		const response = await axiosAdminInstance.get("/organization-file/all");
		return response.data;
	} catch (error) {
		return rejectWithValue(error);
	}
});

export const orgDeleteFileApi = createAsyncThunk("org/deleteFile", async (fileId: string, { rejectWithValue }) => {
	try {
		const response = await axiosAdminInstance.delete(`/organization-file/${fileId}`);
		return response.data;
	} catch (error) {
		return rejectWithValue(error);
	}
});

export const settingGetAppConfigApi = createAsyncThunk("setting/getAppConfig", async (_, { rejectWithValue }) => {
	try {
		const response = await axiosAdminInstance.get("/organization-app-config/app-config");
		return response.data;
	} catch (error) {
		return rejectWithValue(error);
	}
});

export const settingUpdateAppConfigApi = createAsyncThunk("setting/updateAppConfig", async (config: any, { rejectWithValue }) => {
	try {
		const response = await axiosAdminInstance.post("/organization-admin/organization-app-config", config);
		return response.data;
	} catch (error) {
		return rejectWithValue(error);
	}
});

export const settingGetAppCurrentConfigApi = createAsyncThunk("setting/getAppCurrentConfig", async (_, { rejectWithValue }) => {
	try {
		const response = await axiosAdminInstance.get("/organization-admin/organization-app-config");
		return response.data;
	} catch (error) {
		return rejectWithValue(error);
	}
});
