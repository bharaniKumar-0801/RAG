from fastapi import APIRouter, UploadFile, File, Form, Depends
from app.utils.auth import get_current_user
import app.services.organization_file_services as organization_file_services
from typing import List
import json
organization_file_router = APIRouter()

@organization_file_router.post("/upload")
async def upload_file(
    category_id: str = Form(...),
    file: UploadFile = File(...),
    tags: str = Form(...),
    user_id: str = Depends(get_current_user),
):
    tag_list = json.loads(tags)
    result = await organization_file_services.organization_upload_file(
        category_id, file, tag_list, user_id
    )
    return {"message": "File uploaded successfully", "data": result}


@organization_file_router.get("/all")
async def get_files(user_id: str = Depends(get_current_user)):
    result = await organization_file_services.organization_get_files(user_id)
    return {"message": "Files fetched successfully", "success": True, "data": result}


@organization_file_router.delete("/{file_id}")
async def delete_file(file_id: str, user_id: str = Depends(get_current_user)):
    result = await organization_file_services.organization_delete_file(file_id, user_id)
    return {"message": "File deleted successfully", "success": True, "data": result}


@organization_file_router.post("/google-drive/upload")
async def upload_google_drive_file(
    category_id: str = Form(...),
    file: UploadFile = File(...),
    user_id: str = Depends(get_current_user),
):
    print(category_id, file, user_id)
    result = await organization_file_services.organization_google_drive_upload_file(
        category_id, file, user_id
    )
    return {"message": "File uploaded successfully", "data": result}
