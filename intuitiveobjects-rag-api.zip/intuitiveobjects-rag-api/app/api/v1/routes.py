from fastapi import APIRouter
from app.api.v1.router.user_router import user_router
from app.api.v1.router.chat_router import chat_router
from app.api.v1.router.organization_router import organization_router
from app.api.v1.router.organization_admin_router import organization_admin_router
from app.api.v1.router.organization_user_router import organization_user_router
from app.api.v1.router.organization_file_router import organization_file_router
from app.api.v1.router.app_config_router import app_config_router
router = APIRouter()

router.include_router(user_router, prefix="/user")
router.include_router(chat_router, prefix="/chat")
router.include_router(organization_router, prefix="/organization")
router.include_router(organization_admin_router, prefix="/organization-admin")
router.include_router(organization_user_router, prefix="/organization-user")
router.include_router(organization_file_router, prefix="/organization-file")
router.include_router(app_config_router, prefix="/organization-app-config")
